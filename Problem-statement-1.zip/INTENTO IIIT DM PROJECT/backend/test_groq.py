from groq import Groq

client = Groq(api_key="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")

response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[
        {"role": "user", "content": "Give me 10 random names of students from IIITDMJ"}
    ]
)

print(response.choices[0].message.content)