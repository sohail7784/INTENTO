import sys
import os

# Add backend to path
sys.path.append(os.path.join(os.getcwd(), 'backend'))

def test_pdf():
    from backend.routes.goals import generate_pdf
    
    goal_text = "Test Goal"
    status = "completed"
    time_taken = "5s"
    steps = [
        {
            "action": "test_action",
            "status": "completed",
            "result": {"output": "This is a test output for the PDF."}
        }
    ]
    evaluation = {
        "efficiency_score": 0.9,
        "confidence_score": 0.95,
        "optimization_suggestions": ["Keep testing."]
    }
    
    try:
        pdf_bytes = generate_pdf(goal_text, status, time_taken, steps, evaluation)
        with open("test_output.pdf", "wb") as f:
            f.write(pdf_bytes)
        print("PDF generated successfully: test_output.pdf")
    except Exception as e:
        print(f"Error generating PDF: {e}")

if __name__ == "__main__":
    test_pdf()
